import { FoodItems } from './food-items';

describe('FoodItems', () => {
  it('should create an instance', () => {
    expect(new FoodItems()).toBeTruthy();
  });
});
