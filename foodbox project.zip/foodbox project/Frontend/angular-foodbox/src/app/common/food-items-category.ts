export class FoodItemsCategory {
    id: number;
    categoryName: String;
}
