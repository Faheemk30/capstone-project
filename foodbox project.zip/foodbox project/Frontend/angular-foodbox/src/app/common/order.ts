export class Order {
    totalQuantity: number;
    totalPrice: number;
}
