import { FoodItemsCategory } from './food-items-category';

describe('FoodItemsCategory', () => {
  it('should create an instance', () => {
    expect(new FoodItemsCategory()).toBeTruthy();
  });
});
