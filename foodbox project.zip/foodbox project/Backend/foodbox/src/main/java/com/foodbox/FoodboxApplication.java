package com.foodbox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodboxApplication.class, args);
	}

}
